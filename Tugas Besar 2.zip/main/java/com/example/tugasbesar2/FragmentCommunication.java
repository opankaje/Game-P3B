package com.example.tugasbesar2;

public interface FragmentCommunication {
    void changePage(String halaman);
}
