package com.example.tugasbesar2;

public class Player {
    int x;
    int y;
    public Player(int x, int y){
        this.x=x;
        this.y=x;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}
