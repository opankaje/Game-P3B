package com.example.tugasbesar2;

public class GameThread implements Runnable{
    protected Thread thread;
    protected UIThreadedWrapper uiThreadedWrapper;

    public GameThread (UIThreadedWrapper uiThreadedWrapper){
        this.uiThreadedWrapper=uiThreadedWrapper;
        this.thread=new Thread(this);
    }

    public void runThread(){
        this.thread.start();
    }

    @Override
    public void run(){
            Player player = new Player(10,0);
            this.uiThreadedWrapper.setPlayer(player);
    }

    public void pauseThread() {

    }
}
